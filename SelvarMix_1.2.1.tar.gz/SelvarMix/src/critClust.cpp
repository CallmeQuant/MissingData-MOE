#include "critClust.hpp"
//****************************************************************************//
// Constructor ***************************************************************//
CritClust::CritClust() {}

CritClust::CritClust(int k, string m, NumericMatrix data, string crit, IntegerVector knownlabels, bool DA)
{
    this->crit = crit;
    this->m = m;
    this->k = k;
    this->data = data;
    this->knownlabels = knownlabels;
    this->DA = DA;
}


List CritClust::ClustBestModel(std::vector<int> numExp)
{
    try {
        // Load the necessary R environments and functions
        Environment MixAll("package:MixAll");
        Environment base("package:base");
        Function dataframe = base["data.frame"];
        Function clusterDiagGaussian = MixAll["clusterDiagGaussian"];
        Function clusterStrategy = MixAll["clusterStrategy"];
        Function learnDiagGaussian = MixAll["learnDiagGaussian"];
        Function missingValues_func = MixAll["missingValues"];
       
        // Create the strategy object
        S4 quick_precise_strategy = clusterStrategy(
            Named("nbTry") = 1, //1
            Named("nbInit") = 50,
            Named("initMethod") = "random", //random
            Named("initAlgo") = "SEM",
            Named("nbInitIteration") = 5,
            Named("initEpsilon") = 1e-4, //0.001
            Named("nbShortRun") = 5, //3, 5
            Named("shortRunAlgo") = "EM",
            Named("nbShortIteration") = 100, //150
            Named("shortEpsilon") = 1e-6, //1e-6
            Named("longRunAlgo") = "EM",
            Named("nbLongIteration") = 200,
            Named("longEpsilon") = 1e-7
        );
        
        // Prepare the data subset based on numExp
        int numVariables = numExp.size();
        NumericMatrix dataAux(data.nrow(), numVariables);
        for(int j = 0; j < numVariables; ++j) {
            // Adjusting for zero-based indexing in C++
            dataAux(_, j) = data(_, numExp[j] - 1);
        }
        
        // Create a data frame from the subset
        DataFrame df = dataframe(dataAux);
        
        S4 xem; // Returned model is S4 obj

        // Create models as a CharacterVector
        CharacterVector models = CharacterVector::create(m);
        
        if(!DA){
            // Unsupervised Clustering with MixAll
            xem = clusterDiagGaussian(
                Named("data") = df,
                Named("nbCluster") = k,
                Named("models") = m,
                Named("strategy") = quick_precise_strategy, 
                Named("criterion") = crit,
                Named("nbCore") = 1
            );
        }
        else{
            // Supervised Classification with MixAll
            IntegerVector labels = knownlabels;
            
            xem = learnDiagGaussian(
                Named("data") = df,
                Named("labels") = labels,
                Named("models") = m,
                Named("algo") = "simul",
                Named("nbIter") = 100,
                Named("epsilon") = 1e-08,
                Named("criterion") = crit,
                Named("nbCore") = 1
            );
        }
        
        // Check for errors in the result
        if (xem.hasSlot("error")) {
            SEXP errorSlot = xem.slot("error");
            if (!Rf_isNull(errorSlot)) {
                return List::create(Named("error") = as<std::string>(errorSlot));
            }
        }
        
        // Extract missing values using missingValues(xem)
        NumericMatrix imputedData = missingValues_func(xem);
        DataFrame missingVals = DataFrame::create(
                                    Named("row") = imputedData(_, 0),
                                    Named("col") = imputedData(_, 1),
                                    Named("value") = imputedData(_, 2)
                                );

        // // Initialize vectors to store row indices, column indices, and imputed values
        // std::vector<int> row_indices;
        // std::vector<int> col_indices;
        // std::vector<double> values;

        // // Loop over the imputed data matrix to extract the imputed values
        // for (int i = 0; i < imputedData.nrow(); ++i) {
        //     for (int j = 0; j < imputedData.ncol(); ++j) {
        //         double imputedValue = imputedData(i, j);
        //         if (!NumericVector::is_na(imputedValue)) {
        //             // Check if the original data had a missing value at this position
        //             if (NumericVector::is_na(data(i, j))) {
        //                 // This value was originally missing and has been imputed
        //                 row_indices.push_back(i + 1); // Adjust for R's 1-based indexing
        //                 col_indices.push_back(j + 1);
        //                 values.push_back(imputedValue);
        //             }
        //         }
        //     }
        // }
        // DataFrame missingVals = DataFrame::create(
        //                                     Named("row") = row_indices,
        //                                     Named("col") = col_indices,
        //                                     Named("value") = values
        //                                 );

        
        
        // Construct the result list with all necessary elements
        List result = List::create(
            Named("criterionValue") = -as<double>(xem.slot("criterion")),
            Named("criterion") = xem.slot("criterionName"),
            Named("nbcluster") = xem.slot("nbCluster"),
            Named("model") = m,
            Named("parameters") = xem.slot("component"),
            Named("proba") = xem.slot("tik"),
            Named("partition") = xem.slot("zi"),
            Named("error") = "No error",
            Named("missingValues") = missingVals
        );
        
        return result;
    }
    catch (std::exception &ex) {
        return List::create(Named("error") = ex.what());
    }
    catch (...) {
        return List::create(Named("error") = "Unknown error occurred in ClustBestModel");
    }
}




 
