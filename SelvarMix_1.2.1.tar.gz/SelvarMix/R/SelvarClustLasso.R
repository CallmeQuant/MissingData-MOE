SelvarClustLasso <- function(
  x,                      # Input data matrix
  nbcluster,              # Number of clusters
  strategy = NULL,        # Strategy for fitting MixAll
  lambda = seq(20, 100, by = 10),  # Lambda sequence for regularization
  rho = seq(1, 2, length = 2),     # Rho sequence for regularization
  type = "lasso",         # Type of regularization
  rank,                   # Optional pre-defined variable ranking
  hsize = 3,              # Hierarchical size parameter
  criterion = "BIC",      # Model selection criterion (BIC or ICL)
  models = "gaussian_pk_sjk",  # Mixture model specification
  rmodel = c("LI", "LB"),  # Regression model types
  imodel = c("LI", "LB"),        # Initialization model types
  nbcores = min(2, detectCores(all.tests = FALSE, logical = FALSE)), # Parallel processing cores
  impute_missing = TRUE,       # control missing value imputation
  scale_data = TRUE        # control data scaling
) {
  # Library Imports and Dependency Check
  if (!requireNamespace("missRanger", quietly = TRUE)) {
    stop("missRanger package is required but not installed.")
  }
  if (!requireNamespace("MixAll", quietly = TRUE)) {
    stop("MixAll package is required but not installed.")
  }
  library(missRanger)
  library(MixAll)
  
  # Suppress warnings to avoid cluttering output
  options(warn = -1)
  
  # Define default strategy if strategy is NULL
  if (is.null(strategy)) {
    quick_precise_strategy <- clusterStrategy(
      nbTry = 1, #1
      nbInit = 50,
      initMethod = "class",
      initAlgo = "EM",
      nbInitIteration = 5,
      initEpsilon = 1e-4,
      nbShortRun = 5,
      shortRunAlgo = "EM",
      nbShortIteration = 100,
      shortEpsilon = 1e-4,
      longRunAlgo = "EM",
      nbLongIteration = 200,
      longEpsilon = 1e-7
    )
    strategy <- quick_precise_strategy
  }
  
  # Input Validation
  # Check the validity of input parameters using a comprehensive validation function
  CheckInputsC(x, nbcluster, lambda, rho, type, hsize, criterion, models, rmodel, imodel, nbcores)
  
  # Data Preprocessing
  # Convert input to matrix and get dimensions
  x <- as.matrix(x)
  n <- as.integer(nrow(x))
  p <- as.integer(ncol(x))
  nbcluster <- as.integer(nbcluster)
  
  # Initialize variable order matrix
  OrderVariable <- matrix(NA, nrow = length(nbcluster), ncol = p)
  
  # Missing Value Handling
  x_imputed <- x
  if (impute_missing) {
    if (any(is.na(x))) {
      cat("Imputing missing values with missRanger\n")
      x_imputed <- missRanger(as.data.frame(x), verbose = 0)
    } else {
      cat("No missing values to impute\n")
    }
  } else {
    if (any(is.na(x))) {
      warning("Missing values present but skip imputing.")
    }
  }
  
  # Scaling Data
  xstd <- x_imputed
  if (scale_data) {
    cat("Scaling data\n")
    xstd <- scale(as.matrix(x_imputed), center = TRUE, scale = TRUE)
  } else {
    cat("Skipping data scaling\n")
  }
  
  # Variable Ranking
  # If set False to both impute_missing and scale_data, the input will be unimputed and unscaled data
  if (missing(rank)) {
    cat("Performing automatic variable ranking\n")
    OrderVariable <- SortvarClust(xstd, nbcluster, type, lambda, rho, nbcores)
  } else {
    # Use provided ranking if available
    for (r in seq_len(nrow(OrderVariable))) {
      OrderVariable[r, ] <- rank
    }
  }
  cat("Variable Ranks: \n")
  print(OrderVariable)
  
  # Supervised Status (Default: Unsupervised)
  supervised <- FALSE 
  knownlabels <- as.integer(1:n)
  
  # Support Multiple Model Selection Criteria
  bestModel <- list()
  if (length(criterion) == 1) {
    cat("Performing variable selection with", criterion, "criterion\n")
    # Use imputed data for variable selection
    VariableSelectRes <- VariableSelection(
      as.matrix(x_imputed), nbcluster, models, criterion, OrderVariable, 
      hsize, supervised, knownlabels, nbcores
    )

    # Dynamic model selection based on criterion
    bestModel[[criterion]] <- ModelSelectionClust(
      VariableSelectRes, as.matrix(x_imputed), rmodel, imodel, nbcores
    )
  } else {
    # Handle multiple criteria sequentially
    for (crit in criterion) {
      cat("Variable selection with", crit, "criterion\n")
      VariableSelectRes <- VariableSelection(
        as.matrix(x_imputed), nbcluster, models, crit, OrderVariable, 
        hsize, supervised, knownlabels, nbcores
      )
      
      # Dynamically create model selection results
      bestModel[[crit]] <- ModelSelectionClust(
        VariableSelectRes, as.matrix(x_imputed), rmodel, imodel, nbcores
      )
    }
  }
  
  # After variable selection and model selection, fit MixAll model to retrieve imputed values
  if (any(is.na(x))) {
    for (i in seq_along(bestModel)) {
      model_name <- names(bestModel)[i]
      finalModel <- bestModel[[i]]
      number_clusters <- finalModel$nbcluster
      # selected_vars <- finalModel$S

      cat("Fitting model to retrieve imputed values for criterion", model_name, "\n")
      
      # Fit the MixAll model on x_selected (original data with missing values)
      clust_result <- clusterDiagGaussian(
        data = x,
        nbCluster = number_clusters,
        models = models, 
        strategy = strategy,
        criterion = criterion 
      )
      
      # Retrieve the imputed values and convert to data.frame
      missingValuesResult <- missingValues(clust_result)
      missingValuesDF <- as.data.frame(missingValuesResult)
      
      # Fit the imputed values to data
      if (!is.null(missingValuesDF) && nrow(missingValuesDF) > 0) {
        x_imputed_final <- x
        x_imputed_final[cbind(missingValuesDF$row, missingValuesDF$col)] <- missingValuesDF$value
      } else {
        x_imputed_final <- x
      }
      
      # Store the imputed dataframe in finalModel
      # Optionally store the clustering result
      finalModel$imputedData <- x_imputed_final
      finalModel$clust_result <- clust_result  
      
      # Update bestModel
      bestModel[[i]] <- finalModel
    }
  } else {
    cat("No missing values in original data, skipping imputation step\n")
  }
  
  # Output Preparation with Robust Error Handling
  output <- PrepareOutput(bestModel)
  
  return(output)
}

# Helper function to prepare output with robust error handling
PrepareOutput <- function(bestModel) {
  output <- list()
  for (name in names(bestModel)) {
    output[[name]] <- ProcessModelOutput(bestModel[[name]])
  }
  # If only one criterion, return the selvarmix object directly
  if (length(output) == 1) {
    return(output[[1]])
  } else {
    return(output)
  }
}

# Process individual model outputs
ProcessModelOutput <- function(modelResult) {
  # Ensure that regparameters exist before modifying them
  if (!is.null(modelResult$regparameters)) {
    # Add column and row names to regression parameters
    if (!is.null(modelResult$U) && length(modelResult$U) != 0)
      colnames(modelResult$regparameters) <- modelResult$U
    if (!is.null(modelResult$R) && length(modelResult$R) != 0)
      rownames(modelResult$regparameters) <- c("intercept", modelResult$R)
  }
  
  # Construct output object
  object <- list(
    S = modelResult$S,
    R = modelResult$R,
    U = modelResult$U,
    W = modelResult$W,
    criterionValue = modelResult$criterionValue,
    criterion = modelResult$criterion,
    model = modelResult$model,
    rmodel = modelResult$rmodel,
    imodel = modelResult$imodel,
    parameters = modelResult$parameters,
    nbcluster = modelResult$nbcluster,
    partition = modelResult$partition,
    proba = modelResult$proba,
    regparameters = modelResult$regparameters,
    imputedData = modelResult$imputedData 
  )
  
  class(object) <- "selvarmix"
  return(object)
}
