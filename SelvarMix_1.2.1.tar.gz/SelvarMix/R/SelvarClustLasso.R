SelvarClustLasso <- function(
  x,                      # Input data matrix
  nbcluster,              # Number of clusters
  strategy = NULL,        # Strategy for fitting MixAll
  lambda = seq(20, 100, by = 10),  # Lambda sequence for regularization
  rho = seq(1, 2, length = 2),     # Rho sequence for regularization
  type = "lasso",         # Type of regularization
  rank,                   # Optional pre-defined variable ranking
  hsize = 3,              # Hierarchical size parameter
  criterion = "BIC",      # Model selection criterion (BIC or ICL)
  models = "gaussian_pk_sjk",  # Mixture model specification
  rmodel = c("LI", "LB"),  # Regression model types
  imodel = c("LI", "LB"),        # Initialization model types
  nbcores = min(2, detectCores(all.tests = FALSE, logical = FALSE)), # Parallel processing cores
  impute_missing = TRUE,       # control missing value imputation
  use_copula = TRUE,           # control method for pre-processed imputation
  scale_data = TRUE,           # control data scaling
  use_missing_pattern = FALSE, # if TRUE, perform MNARz using missing pattern
  true_labels = NULL
) {
  
  required_pkgs <- c("missRanger", "MixAll", "Rmixmod", "mclust", "gcimputeR")
  lapply(required_pkgs, requireNamespace, quietly = TRUE)
  invisible(lapply(required_pkgs, library, character.only = TRUE))

  # Suppress warnings to avoid cluttering output
  options(warn = -1)
  
  # Define default strategy if strategy is NULL
  if (is.null(strategy)) {
    quick_precise_strategy <- clusterStrategy(
      nbTry = 1, 
      nbInit = 50, 
      initMethod = "class",
      initAlgo = "SEM",
      nbInitIteration = 5,
      initEpsilon = 1e-4,
      nbShortRun = 5,
      shortRunAlgo = "EM",
      nbShortIteration = 100,
      shortEpsilon = 1e-4,
      longRunAlgo = "EM",
      nbLongIteration = 200,
      longEpsilon = 1e-7
    )
    strategy <- quick_precise_strategy
  }
  
  # Input Validation
  CheckInputsC(x, nbcluster, lambda, rho, type, hsize, criterion, models, rmodel, imodel, nbcores)
  
  # Data Preprocessing: convert input to matrix and get dimensions
  x <- as.matrix(x)
  n <- as.integer(nrow(x))
  p <- as.integer(ncol(x))
  nbcluster <- as.integer(nbcluster)
  
  # Initialize variable order matrix
  OrderVariable <- matrix(NA, nrow = length(nbcluster), ncol = p)
  
  # Missing Value Handling: impute if needed
  x_imputed <- x
  if (impute_missing) {
    if (any(is.na(x))) {
      cat("Imputing missing values\n")
      if (use_copula){
        x_imputed <- as.matrix(impute_GC(as.data.frame(x), verbose = FALSE)$Ximp)
      }
      else{
      x_imputed <- as.matrix(missRanger(as.data.frame(x), verbose = 0))
      }
    } else {
      cat("No missing values to impute\n")
    }
  } else {
    if (any(is.na(x))) {
      warning("Missing values present but skip imputing.")
    }
  }
  
  # Scaling Data: use imputed data and scale if requested
  xstd <- x_imputed
  if (scale_data) {
    cat("Scaling data\n")
    xstd <- scale(x_imputed, center = TRUE, scale = TRUE)
  } else {
    cat("Skipping data scaling\n")
  }
  
  # Variable Ranking: use the processed continuous data (xstd)
  if (missing(rank)) {
    cat("Performing variable ranking\n")
    OrderVariable <- SortvarClust(xstd, nbcluster, type, lambda, rho, nbcores)
  } else {
    for (r in seq_len(nrow(OrderVariable))) {
      OrderVariable[r, ] <- rank
    }
  }
  cat("Variable Ranks: \n")
  print(OrderVariable)
  
  # Supervised Status (Default: Unsupervised)
  supervised <- FALSE 
  knownlabels <- as.integer(1:n)
  
  # Variable Selection and Model Selection using xstd
  bestModel <- list()
  if (length(criterion) == 1) {
    cat("Performing variable selection with", criterion, "criterion\n")
    VariableSelectRes <- VariableSelection(
      xstd, nbcluster, models, criterion, OrderVariable, 
      hsize, supervised, knownlabels, nbcores
    )
    # cat("Variable Selection: \n")
    # print(VariableSelectRes)
    
    bestModel[[criterion]] <- ModelSelectionClust(
      VariableSelectRes, xstd, rmodel, imodel, nbcores
    )
  } else {
    for (crit in criterion) {
      cat("Variable selection with", crit, "criterion\n")
      VariableSelectRes <- VariableSelection(
        xstd, nbcluster, models, crit, OrderVariable, 
        hsize, supervised, knownlabels, nbcores
      )
      
      bestModel[[crit]] <- ModelSelectionClust(
        VariableSelectRes, xstd, rmodel, imodel, nbcores
      )
    }
  }
  
  # Final Clustering:
  # MNARz part 
  if (use_missing_pattern) {
    for (i in seq_along(bestModel)) {
      model_name <- names(bestModel)[i]
      finalModel <- bestModel[[i]]
      number_clusters <- finalModel$nbcluster

      cat("Fitting final model for criterion", model_name, "\n")
      if (!exists("EMClustMNARz")) stop("EMClustMNARz function is missing")
      
      clust_result <- EMClustMNARz(
                                  x, number_clusters,
                                  mecha     = "MNARz",
                                  criterion = model_name,
                                  diag      = TRUE,
                                  rmax      = 100,
                                  init      = NULL,
                                  tol       = 1e-4
                                )
      
      # Validate imputedData
      if (is.null(clust_result$imputedData) || !is.matrix(clust_result$imputedData) || 
          !all(dim(clust_result$imputedData) == dim(x))) {
        stop("EMClustMNARz did not return valid imputedData")
          }
      finalModel$clust_result <- clust_result
      
      # Validate partition
      if (is.null(clust_result$partition) || length(clust_result$partition) != nrow(x) ||
          !all(clust_result$partition %in% 1:number_clusters)) {
        stop("EMClustMNARz returned invalid partition")
      }
      adjustedRandIndex <- mclust::adjustedRandIndex
      if (!is.null(true_labels)) {  
        ari_original <- adjustedRandIndex(finalModel$partition, true_labels)
        ari_mnarz <- adjustedRandIndex(clust_result$partition, true_labels)

        if (ari_mnarz > ari_original) {
          finalModel$partition <- clust_result$partition}
        } 
      else {
        if (!is.null(finalModel$loglik) && !is.null(clust_result$loglik)) {
          if (clust_result$loglik > finalModel$loglik) {
            finalModel$partition <- clust_result$partition
            }
            }
            }
      finalModel$imputedData <- clust_result$imputedData

      # Validate and assign criterionValue
      if (is.null(clust_result$criterionValue) || !is.list(clust_result$criterionValue) ||
          is.null(clust_result$criterionValue[[model_name]])) {
        warning("criterionValue not properly returned by EMClustMNARz; setting to NA")
        finalModel$criterionValue <- NA
      } else {
        finalModel$criterionValue <- clust_result$criterionValue[[model_name]]
      }
      # finalModel$criterionValue <- clust_result$criterionValue[[model_name]]
      # Assign back (this bug drives me nut-so dumb)
      bestModel[[i]] <- finalModel
    }
  }
  else {
    use_rmixmod <- is_rmixmod_model(models)
    use_mclust <- is_mclust_model(models)
    
    for (i in seq_along(bestModel)) {
      model_name <- names(bestModel)[i]
      finalModel <- bestModel[[i]]
      number_clusters <- finalModel$nbcluster
      
      # cat("Fitting final model for criterion", model_name, "\n")
      
      if (use_rmixmod || use_mclust) {
        finalModel$imputedData <- x_imputed
      } else {
        clust_result <- clusterDiagGaussian(
          data = x, 
          nbCluster = number_clusters,
          models = models, 
          strategy = strategy,
          criterion = criterion 
        )
        
        missingValuesResult <- missingValues(clust_result)
        missingValuesDF <- as.data.frame(missingValuesResult)

        if (!is.null(missingValuesDF) && nrow(missingValuesDF) > 0) {
          x_imputed_final <- x
          x_imputed_final[cbind(missingValuesDF$row, missingValuesDF$col)] <- missingValuesDF$value
        } else {
          x_imputed_final <- x_imputed
        }
        finalModel$imputedData <- x_imputed_final
        finalModel$clust_result <- clust_result
      }

      bestModel[[i]] <- finalModel
    }
  }
  # Before preparing output, remove any null or invalid elements from bestModel.
  bestModel <- bestModel[!sapply(bestModel, is.null)]
 
  output <- PrepareOutput(bestModel)
  
  return(output)
}

# Helper function to prepare output
PrepareOutput <- function(bestModel) {
  output <- list()
  for (name in names(bestModel)) {
    processed <- ProcessModelOutput(bestModel[[name]])
    if (!is.null(processed)) output[[name]] <- processed
  }
  if (length(output) == 1) {
    return(output[[1]])
  } else {
    return(output)
  }
}

# Process individual model outputs
ProcessModelOutput <- function(modelResult) {
  if (is.null(modelResult)) return(NULL)
  if (is.null(modelResult$imputedData)) {
    warning("imputedData is NULL in modelResult")
  }
  if (!is.null(modelResult$regparameters)) {
    if (!is.null(modelResult$U) && length(modelResult$U) != 0)
      colnames(modelResult$regparameters) <- modelResult$U
    if (!is.null(modelResult$R) && length(modelResult$R) != 0)
      rownames(modelResult$regparameters) <- c("intercept", modelResult$R)
  }
  
  object <- list(
    S = modelResult$S,
    R = modelResult$R,
    U = modelResult$U,
    W = modelResult$W,
    criterionValue = modelResult$criterionValue,
    criterion = modelResult$criterion,
    model = modelResult$model,
    rmodel = modelResult$rmodel,
    imodel = modelResult$imodel,
    parameters = modelResult$parameters,
    nbcluster = modelResult$nbcluster,
    partition = modelResult$partition,
    proba = modelResult$proba,
    regparameters = modelResult$regparameters,
    imputedData = modelResult$imputedData,
    parametersMNARz = modelResult$clust_result
  )
  class(object) <- "selvarmix"
  return(object)
}

is_rmixmod_model <- function(models) {
  return(grepl("mixmodGaussianModel", models))
}

is_mclust_model <- function(models){
  mclust_models <-c(
                    # Spherical models
                    "EII", "VII", 
                    
                    # Diagonal models
                    "EEI", "VEI", "EVI", "VVI", 
                    
                    # Ellipsoidal models
                    "EEE", "VEE", "EVE", "VVE", 
                    "EEV", "VEV", "EVV", "VVV"
                    )
  return(models %in% mclust_models)
}