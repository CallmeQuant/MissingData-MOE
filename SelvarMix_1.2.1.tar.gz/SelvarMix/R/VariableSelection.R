VariableSelection <- function(data,
                              nbcluster,
                              models,
                              criterion,
                              OrderVariable,
                              hsize,
                              supervised,
                              z,
                              nbcores) {
  library(MixAll)
  library(parallel)
  
  data <- as.matrix(data)
  nbcluster <- as.integer(nbcluster)
  criterion <- as.character(criterion)
  
  # Define the model type
  model_type <- if (models == "gaussian_pk_sjk") {
    "gaussian_pk_sjk"
  } else {
    "gaussian_pk_sjk" 
  }
  
  nbcluster.size <- length(nbcluster)
  
  # Wrapper function for parallel processing
  wrapper.selectVar <- function(current_nbcluster, current_ordervar) {
    # Call rcppSelectS to select S variables
    my.list <- tryCatch(
      rcppSelectS(data, 
                  current_ordervar, 
                  current_nbcluster, 
                  model_type, 
                  hsize, 
                  criterion,
                  as.integer(z),
                  supervised),
      error = function(e) list(error = e$message)
    )
    
    # Check for errors
    if ("error" %in% names(my.list)) {
      return(my.list)
    }
    
    # Ensure "S" is present in the result
    if (!"S" %in% names(my.list)) {
      return(list(error = "Output from rcppSelectS does not contain 'S'"))
    }
    
    # Extract the S variables
    ResSelectVar <- list(
      S = my.list$S,
      criterionValue = my.list$criterionValue,
      criterion = my.list$criterion,
      model = my.list$model,
      nbcluster = my.list$nbcluster,
      parameters = my.list$parameters,
      partition = my.list$partition,
      proba = my.list$proba,
      missingValues = my.list$missingValues
    )
    
    # Select W variables using rcppSelectW
    OrderAux <- setdiff(current_ordervar, ResSelectVar$S)
    ResSelectVar$W <- rcppSelectW(data, OrderAux, ResSelectVar$S, hsize)
    
    # Determine U variables
    ResSelectVar$U <- setdiff(seq_len(ncol(data)), union(ResSelectVar$S, ResSelectVar$W))
    
    return(ResSelectVar)
  }
  
  # Adjust the number of cores if necessary
  if (nbcluster.size < nbcores || nbcores < 1) {
    nbcores <- max(1, nbcluster.size)
  }
  
  # Prepare input for processing
  input_list <- lapply(seq_along(nbcluster), function(i) {
    list(
      nbcluster = nbcluster[i],
      ordervar = if (nrow(OrderVariable) > 1) OrderVariable[i, ] else OrderVariable[1, ]
    )
  })
  
  # Parallel processing
  if (.Platform$OS.type == "windows") {
    cl <- makeCluster(nbcores)
    common.objects <- c("data", "models", "hsize", "criterion", "supervised", "z")
    clusterExport(cl, varlist = common.objects, envir = environment())
    clusterEvalQ(cl, library(MixAll))
    junk <- parLapply(cl, input_list, function(x) {
      wrapper.selectVar(x$nbcluster, x$ordervar)
    })
    stopCluster(cl)
  } else {
    junk <- mclapply(
      X = input_list,
      FUN = function(x) wrapper.selectVar(x$nbcluster, x$ordervar),
      mc.cores = nbcores,
      mc.silent = FALSE,
      mc.preschedule = TRUE,
      mc.cleanup = TRUE
    )
  }
  
  # Initialize the result list
  VariableSelectRes <- list()
  idx <- 1
  
  # Process the results
  for (ll in seq_along(junk)) {
    if (is.list(junk[[ll]]) && "S" %in% names(junk[[ll]])) {
      VariableSelectRes[[idx]] <- list(
        S = junk[[ll]]$S,
        W = junk[[ll]]$W,
        U = junk[[ll]]$U,
        criterionValue = junk[[ll]]$criterionValue,
        criterion = junk[[ll]]$criterion,
        model = junk[[ll]]$model,
        nbcluster = junk[[ll]]$nbcluster,
        parameters = junk[[ll]]$parameters,
        partition = junk[[ll]]$partition,
        proba = junk[[ll]]$proba,
        missingValues = junk[[ll]]$missingValues 
      )
      idx <- idx + 1
    } else {
      warning(paste("Error in processing junk[[", ll, "]]: ",
                    if ("error" %in% names(junk[[ll]])) junk[[ll]]$error else "Unexpected format", sep = ""))
    }
  }
  
  # Check if all results failed
  if (length(VariableSelectRes) == 0) {
    stop("All model fittings failed. Please check your data and parameters.")
  }
  
  return(VariableSelectRes)
}